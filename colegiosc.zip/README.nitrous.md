# Setup

Welcome to your Laravel 5 example project on Nitrous.

## Running the development server:

In the [Nitrous IDE](https://community.nitrous.io/docs/ide-overview), start Laravel 5 Example via "Run > Start Laravel 5 Example"

Now you've got a development server running and can see the output in the Nitrous terminal window. You can open up a new shell or utilize [tmux](https://community.nitrous.io/docs/tmux) to open new shells to run other commands.

## Preview the app

In the Nitrous IDE, open the "Preview" menu and click "Port 8000".
