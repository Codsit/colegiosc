<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAlumnosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('alumno', function (Blueprint $table) {
            $table->increments('id_alumno');
            $table->string('dni',8)->unique();
            $table->string('n_c_e',20);
            $table->string('f_naci_alum');
            $table->string('apellido_p',20);
            $table->string('apellido_m',20);
            $table->string('nombre',20);
            $table->string('distrito',20);
            $table->string('region',20);
            $table->string('pais',20);
            $table->string('direccion',50);
            $table->string('telefono',15);
            $table->string('celular',15);
            $table->string('correo',50);
            $table->string('c_procedencia',50);
            $table->string('seguro',2);

            $table->integer('apoderado_id')->unsigned();
            $table->foreign('apoderado_id')->references('id_apoderado')->on('apoderado');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('alumnos');
    }
}
