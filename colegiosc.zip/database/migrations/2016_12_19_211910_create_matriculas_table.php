<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMatriculasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('matricula', function (Blueprint $table) {
            $table->increments('id_matricula');
            $table->string('anio_escolar');
            $table->string('nivel_acad');
            $table->string('grado');
            //--------------------key foreing
            $table->integer('alumno_id')->unsigned();
            $table->foreign('alumno_id')->references('id_alumno')->on('alumno');
            //--------------------key foreing
            $table->integer('doc_id')->unsigned();
            $table->foreign('doc_id')->references('id_doc_matricula')->on('doc_matricula');




        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('matriculas');
    }
}
