<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateApoderadosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('apoderado', function (Blueprint $table) {
            $table->increments('id_apoderado');
            $table->string('a_dni');
            $table->string('n_c_e_a');
            $table->string('f_naci_apoderado');
            $table->string('apellido_p_a');
            $table->string('nombre_a');
            $table->string('distrito_a');
            $table->string('region_a');
            $table->string('pais_a');
            $table->string('dieccion_a');
            $table->string('telefono_a');
            $table->string('celular_a');
            $table->string('correo_a');
            $table->string('ocupacion');
            $table->string('v_con_estudiante');
            $table->string('grado_instruccion');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('apoderados');
    }
}
