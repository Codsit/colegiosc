<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDocMatriculasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('doc_matricula', function (Blueprint $table) {
            $table->increments('id_doc_matricula');
            $table->string('doc_partida_naci');
            $table->string('doc_libreta_nota');
            $table->string('doc_f_matricula');
            $table->string('doc_certf_estud');
            $table->string('doc_certif_conduc');
            $table->string('doc_otros');
            $table->string('doc_foto');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('doc_matriculas');
    }
}
