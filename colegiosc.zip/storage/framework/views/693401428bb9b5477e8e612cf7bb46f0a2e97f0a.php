<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			<?php echo $title; ?>

		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<span class="fa fa-<?php echo e($icone); ?>"></span> <?php echo $fil; ?>

			</li>
		</ol>
	</div>
</div>