<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->

	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Mon site</title>
		<meta name="description" content="">	
		<meta name="viewport" content="width=device-width, initial-scale=1">

        <?php echo e(HTML::style('assets/admin-all-demo.css')); ?>


		<!--[if (lt IE 9) & (!IEMobile)]>
			<?php echo HTML::script('js/vendor/respond.min.js'); ?>

		<![endif]-->
		<!--[if lt IE 9]>
			<?php echo e(HTML::style('https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.js')); ?>

			<?php echo e(HTML::style('https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js')); ?>

		<![endif]-->

		<?php echo HTML::style('http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800'); ?>

		<?php echo HTML::style('http://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic'); ?>


        <?php echo $__env->yieldContent('head'); ?>

	</head>

  <body>

	<!--[if lte IE 7]>
	    <p class="browsehappy">Vous utilisez un navigateur <strong>obsolète</strong>. S'il vous plaît <a href="http://browsehappy.com/">Mettez le à jour</a> pour améliorer votre navigation.</p>
	<![endif]-->

   <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php if(session('statut') == 'admin'): ?>
                    <?php echo link_to_route('admin', trans('back/admin.administration'), [], ['class' => 'navbar-brand']); ?>

                <?php else: ?>
                    <?php echo link_to_route('blog.index', trans('back/admin.redaction'), [], ['class' => 'navbar-brand']); ?>

                <?php endif; ?>
            </div>
            <!-- Menu supérieur -->
            <ul class="nav navbar-right top-nav">
                <li><?php echo link_to_route('home', trans('back/admin.home')); ?></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="fa fa-user"></span> <?php echo e(auth()->user()->username); ?><b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="<?php echo url('auth/logout'); ?>"><span class="fa fa-fw fa-power-off"></span> <?php echo e(trans('back/admin.logout')); ?></a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Menu de la barre latérale -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <?php if(session('statut') == 'admin'): ?>
                        <li <?php echo classActivePath('admin'); ?>>
                             <a href="<?php echo route('admin'); ?>"><span class="fa fa-fw fa-dashboard"></span> <?php echo e(trans('back/admin.dashboard')); ?></a>
                        </li>
                        <li <?php echo classActiveSegment(1, 'user'); ?>>
                            <a href="#" data-toggle="collapse" data-target="#usermenu"><span class="fa fa-fw fa-user"></span> <?php echo e(trans('back/admin.users')); ?> <span class="fa fa-fw fa-caret-down"></span></a>
                            <ul id="usermenu" class="collapse">
                                <li><a href="<?php echo url('user'); ?>"><?php echo e(trans('back/admin.see-all')); ?></a></li>
                                <li><a href="<?php echo url('user/create'); ?>"><?php echo e(trans('back/admin.add')); ?></a></li>
                                <li><a href="<?php echo url('user/roles'); ?>"><?php echo e(trans('back/roles.roles')); ?></a></li>
                            </ul>
                        </li>
                        <li <?php echo classActivePath('contact'); ?>>
                            <a href="<?php echo url('contact'); ?>"><span class="fa fa-fw fa-envelope"></span> <?php echo e(trans('back/admin.messages')); ?></a>
                        </li>  
                        <li <?php echo classActivePath('comment'); ?>>
                            <a href="<?php echo url('comment'); ?>"><span class="fa fa-fw fa-comments"></span> <?php echo e(trans('back/admin.comments')); ?></a>
                        </li> 
                    <?php endif; ?>                  
                    <li <?php echo classActivePath('medias'); ?>>
                        <a href="<?php echo route('medias'); ?>"><span class="fa fa-fw fa-file-image-o"></span> <?php echo e(trans('back/admin.medias')); ?></a>
                    </li>
                    <li <?php echo classActiveSegment(1, 'blog'); ?>>
                        <a href="#" data-toggle="collapse" data-target="#articlemenu"><span class="fa fa-fw fa-pencil"></span> <?php echo e(trans('back/admin.posts')); ?> <span class="fa fa-fw fa-caret-down"></a>
                        <ul id="articlemenu" class="collapse">
                            <li><a href="<?php echo url('blog'); ?>"><?php echo e(trans('back/admin.see-all')); ?></a></li>
                            <li><a href="<?php echo url('blog/create'); ?>"><?php echo e(trans('back/admin.add')); ?></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <?php echo $__env->yieldContent('main'); ?>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /.page-wrapper -->

    </div>
    <!-- /.wrapper -->

        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
        <?php echo HTML::script('js/plugins.js'); ?>

    	<?php echo HTML::script('js/main.js'); ?>


        <?php echo $__env->yieldContent('scripts'); ?>

  </body>
</html>