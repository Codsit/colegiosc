
<div class="col-md-6">
    <div class="tile-box tile-box-alt mrg20B <?php echo e($color); ?>">
        <div class="tile-header">
            New Visitors
        </div>
        <div class="tile-content-wrapper">
            <i class="glyph-icon <?php echo e($icone); ?>"></i>
            <div class="tile-content">
                <span></span>
                <?php echo e($nbr['total'] . ' ' . $total); ?>

            </div>
            <small>
                <i class="glyph-icon icon-caret-up"></i>
                + <?php echo e($nbr['new']); ?> <?php echo e($name); ?>

            </small>
        </div>
        <a href="<?php echo e($url); ?>" class="tile-footer tooltip-button" data-placement="bottom" title="" data-original-title="<?php echo e($nbr['total'] . ' ' . $total); ?>">
            Ver Detalles
            <i class="glyph-icon icon-arrow-right"></i>
        </a>
    </div>
</div>