<?php $__env->startSection('main'); ?>

 <!-- Entête de page -->
  <?php echo $__env->make('back.partials.entete', ['title' => trans('back/users.dashboard'), 'icone' => 'user', 'fil' => link_to('user', trans('back/users.Users')) . ' / ' . trans('back/users.creation')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="col-sm-12">
		<?php echo Form::open(['url' => 'user', 'method' => 'post', 'class' => 'form-horizontal panel']); ?>	
			<?php echo Form::control('text', 0, 'username', $errors, trans('back/users.name')); ?>

			<?php echo Form::control('email', 0, 'email', $errors, trans('back/users.email')); ?>

			<?php echo Form::control('password', 0, 'password', $errors, trans('back/users.password')); ?>

			<?php echo Form::control('password', 0, 'password_confirmation', $errors, trans('back/users.confirm-password')); ?>

			<?php echo Form::selection('role', $select, null, trans('back/users.role')); ?>

			<?php echo Form::submit(trans('front/form.send')); ?>

		<?php echo Form::close(); ?>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>