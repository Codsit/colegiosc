<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2><?php echo e($title); ?></h2>

		<div>
			<?php echo $intro . link_to('auth/confirm/' . $confirmation_code, $link); ?>.<br>
		</div>
	</body>
</html>
