<?php $__env->startSection('main'); ?>

  <?php echo $__env->make('back.partials.entete', ['title' => trans('back/roles.dashboard'), 'icone' => 'user', 'fil' => link_to('user', trans('back/users.Users')) . ' / ' . trans('back/roles.roles')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="col-sm-12">
		<?php if(session()->has('ok')): ?>
			<?php echo $__env->make('partials/error', ['type' => 'success', 'message' => session('ok')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endif; ?>
		<?php echo Form::open(['url' => 'user/roles', 'method' => 'post', 'class' => 'form-horizontal panel']); ?>	
			<?php foreach($roles as $role): ?> 
				<?php echo Form::control('text', 0, $role->slug, $errors, trans('back/roles.' . $role->slug), $role->title); ?>

			<?php endforeach; ?>
			<?php echo Form::submit(trans('front/form.send')); ?>

		<?php echo Form::close(); ?>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>