<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2><?php echo e($title); ?></h2>

		<div>
			<?php echo $intro . link_to('password/reset/' . $token, $link); ?>.<br>
			<?php echo e($expire . config('auth.reminder.expire', 60) . $minutes); ?>.
		</div>
	</body>
</html>
