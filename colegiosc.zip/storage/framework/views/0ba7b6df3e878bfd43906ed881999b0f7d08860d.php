<?php $__env->startSection('main'); ?>

    <!-- Main Content -->
    <main class="main-content">
        <div class="tc-padding">
            <div class="container">

                <!-- Main Heading -->
                <div class="container">
                    <div class="main-heading-holder">
                        <div class="main-heading">
                            <h2>blog masonry</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing aelit, sed do eiusmod tempor incididunt.</p>
                        </div>
                    </div>
                </div>
                <!-- Main Heading -->
                <!-- Blog Masonry Grid -->
                <div class="simple-masonry row">

        <?php foreach($posts as $post): ?>
            <!-- Masonry Event Grid -->
                <div class="simple-masonry-grid col-sm-4 col-xs-6 r-full-width">
                    <div class="blog-column tc-hover tranding-post">
                        <img src="images/blog-masonry/img-01.jpg" alt="">
                        <div class="blog-detail">
                            <ul class="meta-post">
                                <li><i class="fa fa-calendar"></i><?php echo $post->created_at . ($post->created_at != $post->updated_at ? trans('front/blog.updated') . $post->updated_at : ''); ?></li>
                                <li><i class="fa fa-user"></i><?php echo e($post->user->username); ?></li>
                            </ul>
                            <h4><?php echo e($post->title); ?></h4>
                            <p><?php echo $post->summary; ?></p>
                            <div class="blog-detail-btm">
                                <?php echo link_to('blog/' . $post->slug, trans('front/blog.button'), ['class' => 'btn blue sm']); ?>

                                <ul class="like-nd-comment">
                                    <li><i class="fa fa-heart-o"></i>5</li>
                                    <li><i class="fa fa-commenting-o"></i>2</li>
                                </ul>
                            </div>
                            <a class="circle-btn" href="#"><i class="fa fa-graduation-cap"></i></a>
                        </div>
                    </div>
                </div>
        <?php endforeach; ?>
     


                </div>
                <!-- Blog Masonry Grid -->

                <div class="col-lg-12 text-center">
                    <?php echo $links; ?>

                </div>

            </div>
        </div>
    </main>
    <!-- Main Content -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>