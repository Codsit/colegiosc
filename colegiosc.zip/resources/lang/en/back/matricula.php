<?php

return [
    'title' => 'Matricula',
    'add' => 'Nueva Matricula'
];