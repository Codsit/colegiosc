<?php

return [
	'error-404' => 'Error 404',
	'info' => 'This page doesn\'t exist !',
	'button' => 'Home'
];