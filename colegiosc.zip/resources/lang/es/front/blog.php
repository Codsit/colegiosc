<?php

return [
	'button' => 'Leer mas',
	'on' => 'Activo',
	'updated' => 'Actualizado',
	'tags' => 'Etiquetas : ',
	'comments' => 'Commentarios',
	'comment' => 'Comentar ?',
	'info-comment' => 'Deves de Loguearte Para comentar !',
	'delete' => 'Eliminar Comentario',
	'edit' => 'Comentario Actualizado',
	'change' => 'Cambia tu comentario allí :',
	'valid' => 'Valido',
	'undo' => 'Deshacer',
	'fail-update' => 'Error en la actualización. Sin datos o texto demasiado largo',
	'fail-delete' => 'Error al Actualizar',
	'warning' => 'Gracias por tu comentario. Aparecerá cuando un administrador lo haya validado (Una vez que se hayan validado sus otros comentarios aparecerán inmediatamente)',
	'search' => 'Buscar',
	'info-tag' => 'Mensajes encontrados con la etiqueta',
	'info-search' => 'Mensajes encontrados con la búsqueda ',
	'confirm' => 'Realmente eliminar este comentario ?'
];