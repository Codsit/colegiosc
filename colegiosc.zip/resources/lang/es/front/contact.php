<?php

return [
	'title' => 'Formulario de contacto',
	'text' => 'Si desea enviar un mensaje, por favor llene este formulario :',
	'name' => 'Tu Nombre',
	'email' => 'Tu Correo',
	'message' => 'Tu Mensaje',
	'ok' => 'Su mensaje ha sido grabado, responderemos lo antes posible.'
];