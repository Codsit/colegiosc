<?php

return [
	'error-404' => 'Error 404',
	'info' => 'Esta Direccion ya No existe !',
	'button' => 'Home'
];