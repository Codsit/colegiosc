<?php

return [
	'dashboard' => 'Gestionar Roles',
	'roles' => 'Roles',
	'admin' => 'Tutulo para adminstrador',
	'redac' => 'Titulo para redactor',
	'user' => 'Titulo para usuario',
	'ok' => 'Rol Actualizado.'
];