<?php

return [
	'administration' => 'Administration',
	'redaction' => 'Redactar',
	'home' => 'Home',
	'logout' => 'Salir',
	'dashboard' => 'Dashboard',
	'users' => 'Usuarios',
	'see-all' => 'Ver todo',
	'add' => 'Añadir',
	'messages' => 'Mesages',
	'comments' => 'Commentarios',
	'medias' => 'Archivos',
	'posts' => 'Publicaciones',
	'new-messages' => 'Nueva Publicacion !',
	'new-registers' => 'Nuevos usuarios !',
	'new-posts' => 'Nuevas Publicaciones !',
	'new-comments' => 'Nuevos Comentarios !'
];
