<?php

return [
	'dashboard' => 'Gestionar Archivos',
	'medias' => 'Archivos'
];