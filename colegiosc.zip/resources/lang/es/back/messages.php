<?php

return [
	'dashboard' => 'Gestionar Mensajes',
	'messages' => 'Mensages ',
	'name' => 'Nombre',
	'email' => 'Email',		
	'date' => 'Fecha',
	'seen' => 'Visto',
	'destroy' => 'Eliminar',
	'destroy-warning' => 'Deseas eliminar mesaje ?',
	'fail' => 'Actualizacion Fallida.'
];