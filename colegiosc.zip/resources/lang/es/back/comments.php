<?php

return [
	'dashboard' => 'Gestionar Comentarios',
	'comments' => 'Commentarios',
	'author' => 'Author',		
	'date' => 'Fecha',
	'post' => 'Publicacion',
	'valid' => 'Validar',
	'seen' => 'Visto',
	'destroy' => 'Eliminar',
	'destroy-warning' => 'Desea eliminar comentario ?',
	'fail' => 'Actualizacion Fallida.'
];