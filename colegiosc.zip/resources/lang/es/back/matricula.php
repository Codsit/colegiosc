<?php

return [
    'title' => 'matricula',
    'add' => 'Nueva Matricula'
];